﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordeaTask.Entity
{
    /// <summary>
    /// This object will return dummy data for service response
    /// </summary>
    public class PriceResponse
    {
        public Dictionary<DateTime, Price[]> Prices { get; set; }
    }
}
