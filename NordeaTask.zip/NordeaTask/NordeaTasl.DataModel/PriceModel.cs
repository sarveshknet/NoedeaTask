﻿using System;
using System.Collections.Generic;
using System.Linq;
using NordeaTask.Entity;

namespace NordeaTask.DataModel
{
    /// <summary>
    /// This is dummy data model which will return price in Dictionary
    /// </summary>
    public class PriceModel
    {
        /// <summary>
        /// private function to return number of required records
        /// </summary>
        /// <returns></returns>
        private Price[] GetPrices()
        {
            Price[] prices = new Price[10000];
            DateTime dt = new DateTime(2019, 01, 01);
            int productKey = 10;

            for (int i = 0; i < 10000; i++)
            {
                if (i % 10 == 0)
                {
                    dt = dt.AddDays(1);
                    productKey = 10;
                }
                prices[i] = new Price { Date = dt, ProductKey = "ProductKey" + productKey.ToString(), Value = (decimal)((i + 1) * 0.1) };
                productKey++;

            }

            return prices;
        }

        /// <summary>
        /// return records by Dictionary key will enhence performance as no need to scan every record for date
        /// </summary>
        /// <returns></returns>
        public Dictionary<DateTime, Price[]> GetPricesAsDictionary()
        {
            Dictionary<DateTime, Price[]> dataDict = new Dictionary<DateTime, Price[]>();
            Price[] prices = GetPrices();

            DateTime[] dates = prices.Select(x => x.Date).Distinct().ToArray();

            foreach (var priceDate in dates)
            {
                if (!dataDict.ContainsKey(priceDate))
                {
                    dataDict.Add(priceDate, prices.Where(x => x.Date == priceDate).ToArray());
                }
            }

            return dataDict;
        }

    }
}
