﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NordeaTask.Entity;

namespace NordeaTask.DataModel
{
    public class PriceServiceModel
    {
        private Price[] GetPrices(DateTime priceStartDate, DateTime priceEndDate)
        {
            TimeSpan NoOfDaysForRequest = priceEndDate - priceStartDate;

            Price[] prices = new Price[NoOfDaysForRequest.Days * 50];
            DateTime dt = new DateTime(2019, 01, 01);
            int productKey = 10;
            int priceIndex = 0;

            while (priceStartDate < priceEndDate)
            {
                for (int i = 0; i < 50; i++)
                {
                    productKey = 10;
                    prices[priceIndex] = new Price { Date = priceStartDate, ProductKey = "Key" + productKey.ToString(), Value = (decimal)(i * 0.1) };

                    priceIndex++;
                    productKey++;
                }

                priceStartDate = priceStartDate.AddDays(1);
            }

            System.Threading.Thread.Sleep(NoOfDaysForRequest.Days * 1000); //TODO added a thread delay for testing

            return prices;
        }

        /// <summary>
        /// this method will return prices for given date range will few seconds delay
        /// </summary>
        /// <param name="priceStartDate"></param>
        /// <param name="priceEndDate"></param>
        /// <returns></returns>
        public PriceResponse GetPricesAsDictionary(DateTime priceStartDate, DateTime priceEndDate)
        {
            Dictionary<DateTime, Price[]> dataDict = new Dictionary<DateTime, Price[]>();
            Price[] prices = GetPrices(priceStartDate, priceEndDate);

            DateTime[] dates = prices.Select(x => x.Date).Distinct().ToArray();

            foreach (var priceDate in dates)
            {
                if (!dataDict.ContainsKey(priceDate))
                {
                    dataDict.Add(priceDate, prices.Where(x => x.Date == priceDate).ToArray());
                }
            }

            PriceResponse p = new PriceResponse();
            p.Prices = dataDict;

            return p;
        }

    }
}
