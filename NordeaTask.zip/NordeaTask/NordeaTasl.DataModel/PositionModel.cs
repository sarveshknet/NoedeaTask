﻿using System;
using System.Collections.Generic;
using System.Linq;
using NordeaTask.Entity;

namespace NordeaTask.DataModel
{
    /// <summary>
    /// This is dummy data model which will return postion in Dictionary
    /// returing by Dictionary key will enhence performance as no need to scan every record
    /// </summary>
    public class PositionModel
    {
        /// <summary>
        /// return records by Dictionary key will enhence performance as no need to scan every record for date
        /// </summary>
        public Dictionary<DateTime, Position[]> GetPositionAsDictionary()
        {
            Dictionary<DateTime, Position[]> dataDict = new Dictionary<DateTime, Position[]>();
            Position[] positions = GetPositions();

            DateTime[] dates = positions.Select(x => x.Date).Distinct().ToArray();

            foreach (var positionDate in dates)
            {
                if (!dataDict.ContainsKey(positionDate))
                {
                    dataDict.Add(positionDate, positions.Where(x => x.Date == positionDate).ToArray());
                }
            }

            return dataDict;
        }

        /// <summary>
        /// Create dummy data for position for test
        /// </summary>
        /// <returns></returns>
        private Position[] GetPositions()
        {
            Position[] positions = new Position[10000];
            DateTime dt = new DateTime(2019, 01, 01);
            int productKey = 10;

            for (int i = 0; i < 10000; i++)
            {
                if (i % 10 == 0)
                {
                    dt = dt.AddDays(1);
                    productKey = 10;
                }
                positions[i] = new Position { ProductKey = "ProductKey" + productKey.ToString(), Date = dt, Amount = i + 5, PositionId = i + 1 };
                productKey++;
            }

            return positions;
        }
    }
}
