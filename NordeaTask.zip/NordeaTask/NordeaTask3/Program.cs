﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NordeaTask.Entity;

namespace NordeaTask3
{
    public class Program
    {
        static void Main(string[] args)
        {
            //Here i have added price data source as dependency injection. 
            //So that it can be changed whenever you want so set any data source/price algorithm
            PriceManager pm = new PriceManager(new PriceDataSource(), new InterpolatedPricesAlgorithm());
            Price[] price = pm.GetPrices();
        }
    }

}
