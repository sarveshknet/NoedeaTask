﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordeaTask3
{
    public class PriceDataSource : IPriceDataSource
    {
        public NordeaTask.Entity.Price[] GetPrices()
        {
            throw null; //TODO there should be logic to for task
        }
    }
}
