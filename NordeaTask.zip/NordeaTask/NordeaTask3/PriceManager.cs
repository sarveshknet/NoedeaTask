﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NordeaTask.Entity;

namespace NordeaTask3
{
    public class PriceManager
    {
        private readonly IPriceDataSource priceDataSource;

        //I have added this interface as you can define many algorithm and call based on dependency injection
        private readonly IInterpolatedPricesAlgorithm interpolatedPricesAlgorithm;


        public PriceManager(IPriceDataSource priceDataSource, IInterpolatedPricesAlgorithm interpolatedPricesAlgorithm)
        {
            this.priceDataSource = priceDataSource;
        }

        public Price[] GetPrices()
        {
            // currently returns prices from source
            // should return interpolated prices
            Price[] prices = priceDataSource.GetPrices();
            prices = interpolatedPricesAlgorithm.GetInterpolatedPricesAlgorithm(prices);
            return prices;
        }
    }
}
