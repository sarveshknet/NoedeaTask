﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NordeaTask.Entity;

namespace NordeaTask3
{
    /// <summary>
    /// This method shoudl implement by class where new also should be define
    /// </summary>
    public interface IInterpolatedPricesAlgorithm
    {
        Price[] GetInterpolatedPricesAlgorithm(Price[] pricesFromSource);
    }
}
