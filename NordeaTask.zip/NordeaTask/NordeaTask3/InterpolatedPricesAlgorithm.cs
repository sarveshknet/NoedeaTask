﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordeaTask3
{
    public class InterpolatedPricesAlgorithm : IInterpolatedPricesAlgorithm
    {
        public NordeaTask.Entity.Price[] GetInterpolatedPricesAlgorithm(NordeaTask.Entity.Price[] pricesFromSource)
        {
            throw null; //TODO there should be logic to for task
        }
    }
}
