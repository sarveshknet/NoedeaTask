﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NordeaTask.DataModel;
using NordeaTask.Entity;

namespace NordeaTask2
{
        class Program
        {
            static void Main(string[] args)
            {
                #region Get prices from 3 different service
                // This method will return price from 1st Jan to 14 Jan with 14 sec delay in asnycronous mode
                PriceServiceModel psm1 = new PriceServiceModel();
                Task<PriceResponse> taskForService1 = new Task<PriceResponse>(
                    () => psm1.GetPricesAsDictionary(new DateTime(2019, 01, 01), new DateTime(2019, 01, 15))); // can be more than 100000 records
                taskForService1.Start();

                // This method will return price from 11th Jan to 24 Jan with 14 sec delay in asnycronous mode
                PriceServiceModel psm2 = new PriceServiceModel();
                Task<PriceResponse> taskForService2 = new Task<PriceResponse>(
                    () => psm1.GetPricesAsDictionary(new DateTime(2019, 01, 11), new DateTime(2019, 01, 25))); // can be more than 100000 records
                taskForService2.Start();

                // This method will return price from 21st Jan to 30 Jan with 10 sec delay in asnycronous mode
                PriceServiceModel psm3 = new PriceServiceModel();
                Task<PriceResponse> taskForService3 = new Task<PriceResponse>(
                    () => psm1.GetPricesAsDictionary(new DateTime(2019, 01, 21), new DateTime(2019, 01, 31))); // can be more than 100000 records
                taskForService3.Start();

                #endregion

                //This method will wait for max call time (14 sec here) as all 3 calls are in asnycronous mode
                Dictionary<DateTime, Price[]> combinedPrices =
                    GetUniquePrice(taskForService1.Result, taskForService2.Result, taskForService3.Result);

            }

            /// <summary>
            /// This method will combine prices for all dates into single unique collection
            /// </summary>
            /// <param name="service1Response"></param>
            /// <param name="service2Response"></param>
            /// <param name="service3Response"></param>
            /// <returns></returns>
            static Dictionary<DateTime, Price[]> GetUniquePrice(PriceResponse service1Response,
                PriceResponse service2Response,
                PriceResponse service3Response)
            {
                // Get all prices from Service 1
                Dictionary<DateTime, Price[]> combinedPrices = service1Response.Prices;

                //add prices from service 2 which were not in service 1
                foreach(var dateKey in service2Response.Prices)
                {
                    if(!combinedPrices.ContainsKey(dateKey.Key)) // if any price for 2 service not availble into service then add same
                    {
                        combinedPrices.Add(dateKey.Key, dateKey.Value);
                    }
                }

                //add prices from service 2 which were not in combinedPrices
                foreach (var dateKey in service3Response.Prices)
                {
                    if (!combinedPrices.ContainsKey(dateKey.Key)) // if any price for 2 service not availble into service then add same
                    {
                        combinedPrices.Add(dateKey.Key, dateKey.Value);
                    }
                }

                return combinedPrices;
            }
        }
}
