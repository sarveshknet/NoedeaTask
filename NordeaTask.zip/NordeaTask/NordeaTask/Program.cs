﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using NordeaTask.Entity;
using NordeaTask.DataModel;

namespace TestConsole
{
    /// <summary>
    /// Task 1 exercise
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            // getting all prices
            PriceModel priceModel = new PriceModel();
            Dictionary<DateTime, Price[]> prices = priceModel.GetPricesAsDictionary(); // can be more than 10000 records

            // getting all positions
            PositionModel positionModel = new PositionModel();
            Dictionary<DateTime, Position[]> positions = positionModel.GetPositionAsDictionary(); // can be more than 10000 records

            //Now as price and positon are coming with Date as Key and Value as collection.
            //So i do not need to scan every record for every key/date. I will scan if dictionary key has date then price are available
            //This will improve performance for program to work with 1 min records in few sec.
            foreach (var positionDate in positions)
            {
                if (prices.ContainsKey(positionDate.Key))
                {
                    Position[] positionForDate = positionDate.Value;
                    Price[] priceForDate = prices[positionDate.Key];
                    
                    // using for loop instead of foreach for better performance as we are not modifying collection
                    for (int i = 0; i < positionForDate.Length - 1; i++)
                    {
                        Position po = positionForDate[i];
                        Price pr = priceForDate.FirstOrDefault(x => x.ProductKey == po.ProductKey);

                        // check and print market value
                        if (pr != null)
                        {
                            decimal valueOnDate = po.Amount * pr.Value;
                            Console.WriteLine(string.Format("For product {0} with date {1} , price is {2}, amount is {3}. So calculated market value is {4}", po.ProductKey,
                                po.Date, pr.Value, po.Amount, valueOnDate));
                        }
                    }
                }
            }
            Console.ReadLine();
        }

    }
}